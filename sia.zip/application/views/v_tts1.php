<div class="content-wrapper container">
                <div class="page-content">
                    <section class="row">
                        <div class="col-12 col-lg-14">
                            <div class="row">
                                <div class="col-12">
                                    <div class="card">
                                        <div class="card-header">
                                            <h4 style="text-align:center; position: relative">Tes Tingkat Stress Mahasiswa</h4>
                                        </div>
                                        <div class="card-content">
                                            <div class="card-body">
                                                <form action="<?=  base_url('Tts/proses') ?>" method="POST" class="form form-vertical">
                                                    <div class="row">
                                                        <div class=" col-12">
                                                            <div class="form-group">
                                                                <h6 for="soal1">1. Dalam sebulan terakhir, seberapa sering Anda merasa kesal karena sesuatu yang terjadi secara tidak terduga?</h6>
                                                                
                                                                    <div  style="display: inline-block; margin:5px;">
                                                                    <input style="width: 200px; text-align:center;" type="radio" name="opsi1" id="a-a" value="a" required><br><label style="width: 200px; text-align:center;" for="a">Tidak Pernah</label>
                                                                    </div>
                                                                    <div style="display: inline-block; margin:5px;">
                                                                    <input style="width: 200px; text-align:center;" type="radio" name="opsi1" id="b-b" value="b"><br><label style="width: 200px; text-align:center;" for="b">Jarang</label>
                                                                    </div>
                                                                    <div style="display: inline-block; margin:5px;">
                                                                    <input style="width: 200px; text-align:center;" type="radio" name="opsi1" id="c-c" value="c"><br><label style="width: 200px; text-align:center;" for="c">Kadang-kadang</label>
                                                                    </div>
                                                                    <div style="display: inline-block; margin:5px;">
                                                                    <input style="width: 200px; text-align:center;" type="radio" name="opsi1" id="d-d" value="d"><br><label style="width: 200px; text-align:center;" for="d">Cukup Sering</label>
                                                                    </div>
                                                                    <div style="display: inline-block; margin:5px;">
                                                                    <input style="width: 200px; text-align:center;" type="radio" name="opsi1" id="e-e" value="e"><br><label style="width: 200px; text-align:center;" for="e">Sering Sekali</label>
                                                                    </div>
                                                            </div>
                                                            <br>
                                                        </div>
                                                        
                                                        <div class=" col-12">
                                                        <div class="form-group">
                                                                <h6 for="soal1">2. Dalam sebulan terakhir, seberapa sering Anda merasa bahwa Anda tidak dapat mengendalikan hal-hal yang penting dalam hidup Anda?</h6>
                                                                
                                                                    <div  style="display: inline-block; margin:5px;">
                                                                    <input style="width: 200px; text-align:center;" type="radio" name="opsi2" id="a" value="a" required><br><label style="width: 200px; text-align:center;" for="a">Tidak Pernah</label>
                                                                    </div>
                                                                    <div style="display: inline-block; margin:5px;">
                                                                    <input style="width: 200px; text-align:center;" type="radio" name="opsi2" id="b" value="b"><br><label style="width: 200px; text-align:center;" for="b">Jarang</label>
                                                                    </div>
                                                                    <div style="display: inline-block; margin:5px;">
                                                                    <input style="width: 200px; text-align:center;" type="radio" name="opsi2" id="c" value="c"><br><label style="width: 200px; text-align:center;" for="c">Kadang-kadang</label>
                                                                    </div>
                                                                    <div style="display: inline-block; margin:5px;">
                                                                    <input style="width: 200px; text-align:center;" type="radio" name="opsi2" id="d" value="d"><br><label style="width: 200px; text-align:center;" for="d">Cukup Sering</label>
                                                                    </div>
                                                                    <div style="display: inline-block; margin:5px;">
                                                                    <input style="width: 200px; text-align:center;" type="radio" name="opsi2" id="e" value="e"><br><label style="width: 200px; text-align:center;" for="e">Sering Sekali</label>
                                                                    </div>
                                                            </div>
                                                            <br>
                                                        </div>
                                                        <div class=" col-12">
                                                        <div class="form-group">
                                                                <h6 for="soal1">3. Dalam sebulan terakhir, seberapa sering Anda merasa gelisah dan stres?</h6>
                                                                
                                                                    <div  style="display: inline-block; margin:5px;">
                                                                    <input style="width: 200px; text-align:center;" type="radio" name="opsi3" id="a" value="a" required><br><label style="width: 200px; text-align:center;" for="a">Tidak Pernah</label>
                                                                    </div>
                                                                    <div style="display: inline-block; margin:5px;">
                                                                    <input style="width: 200px; text-align:center;" type="radio" name="opsi3" id="b" value="b"><br><label style="width: 200px; text-align:center;" for="b">Jarang</label>
                                                                    </div>
                                                                    <div style="display: inline-block; margin:5px;">
                                                                    <input style="width: 200px; text-align:center;" type="radio" name="opsi3" id="c" value="c"><br><label style="width: 200px; text-align:center;" for="c">Kadang-kadang</label>
                                                                    </div>
                                                                    <div style="display: inline-block; margin:5px;">
                                                                    <input style="width: 200px; text-align:center;" type="radio" name="opsi3" id="d" value="d"><br><label style="width: 200px; text-align:center;" for="d">Cukup Sering</label>
                                                                    </div>
                                                                    <div style="display: inline-block; margin:5px;">
                                                                    <input style="width: 200px; text-align:center;" type="radio" name="opsi3" id="e" value="e"><br><label style="width: 200px; text-align:center;" for="e">Sering Sekali</label>
                                                                    </div>
                                                            </div>
                                                        <br>

                                                        </div>
                                                        <div class=" col-12">
                                                        <div class="form-group">
                                                                <h6 for="soal1">4. Dalam sebulan terakhir, seberapa sering Anda merasa yakin terhadap kemampuan Anda dalam menangani masalah pribadi?</h6>
                                                                
                                                                    <div  style="display: inline-block; margin:5px;">
                                                                    <input style="width: 200px; text-align:center;" type="radio" name="opsi4" id="a" value="a" required><br><label style="width: 200px; text-align:center;" for="a">Tidak Pernah</label>
                                                                    </div>
                                                                    <div style="display: inline-block; margin:5px;">
                                                                    <input style="width: 200px; text-align:center;" type="radio" name="opsi4" id="b" value="b"><br><label style="width: 200px; text-align:center;" for="b">Jarang</label>
                                                                    </div>
                                                                    <div style="display: inline-block; margin:5px;">
                                                                    <input style="width: 200px; text-align:center;" type="radio" name="opsi4" id="c" value="c"><br><label style="width: 200px; text-align:center;" for="c">Kadang-kadang</label>
                                                                    </div>
                                                                    <div style="display: inline-block; margin:5px;">
                                                                    <input style="width: 200px; text-align:center;" type="radio" name="opsi4" id="d" value="d"><br><label style="width: 200px; text-align:center;" for="d">Cukup Sering</label>
                                                                    </div>
                                                                    <div style="display: inline-block; margin:5px;">
                                                                    <input style="width: 200px; text-align:center;" type="radio" name="opsi4" id="e" value="e"><br><label style="width: 200px; text-align:center;" for="e">Sering Sekali</label>
                                                                    </div>
                                                            </div>
                                                        <br>

                                                        </div>
                                                        <div class=" col-12">
                                                        <div class="form-group">
                                                                <h6 for="soal1">5. Dalam sebulan terakhir, seberapa sering Anda merasa bahwa segala sesuatu berjalan sesuai keinginan Anda?</h6>
                                                                
                                                                    <div  style="display: inline-block; margin:5px;">
                                                                    <input style="width: 200px; text-align:center;" type="radio" name="opsi5" id="a" value="a" required><br><label style="width: 200px; text-align:center;" for="a">Tidak Pernah</label>
                                                                    </div>
                                                                    <div style="display: inline-block; margin:5px;">
                                                                    <input style="width: 200px; text-align:center;" type="radio" name="opsi5" id="b" value="b"><br><label style="width: 200px; text-align:center;" for="b">Jarang</label>
                                                                    </div>
                                                                    <div style="display: inline-block; margin:5px;">
                                                                    <input style="width: 200px; text-align:center;" type="radio" name="opsi5" id="c" value="c"><br><label style="width: 200px; text-align:center;" for="c">Kadang-kadang</label>
                                                                    </div>
                                                                    <div style="display: inline-block; margin:5px;">
                                                                    <input style="width: 200px; text-align:center;" type="radio" name="opsi5" id="d" value="d"><br><label style="width: 200px; text-align:center;" for="d">Cukup Sering</label>
                                                                    </div>
                                                                    <div style="display: inline-block; margin:5px;">
                                                                    <input style="width: 200px; text-align:center;" type="radio" name="opsi5" id="e" value="e"><br><label style="width: 200px; text-align:center;" for="e">Sering Sekali</label>
                                                                    </div>
                                                            </div>
                                                        <br>

                                                        </div>
                                                        <div class=" col-12">
                                                        <div class="form-group">
                                                                <h6 for="soal1">6. Dalam sebulan terakhir, seberapa sering Anda mampu mengendalikan hal-hal yang mengganggu dalam hidup Anda?</h6>
                                                                
                                                                    <div  style="display: inline-block; margin:5px;">
                                                                    <input style="width: 200px; text-align:center;" type="radio" name="opsi6" id="a" value="a" required><br><label style="width: 200px; text-align:center;" for="a">Tidak Pernah</label>
                                                                    </div>
                                                                    <div style="display: inline-block; margin:5px;">
                                                                    <input style="width: 200px; text-align:center;" type="radio" name="opsi6" id="b" value="b"><br><label style="width: 200px; text-align:center;" for="b">Jarang</label>
                                                                    </div>
                                                                    <div style="display: inline-block; margin:5px;">
                                                                    <input style="width: 200px; text-align:center;" type="radio" name="opsi6" id="c" value="c"><br><label style="width: 200px; text-align:center;" for="c">Kadang-kadang</label>
                                                                    </div>
                                                                    <div style="display: inline-block; margin:5px;">
                                                                    <input style="width: 200px; text-align:center;" type="radio" name="opsi6" id="d" value="d"><br><label style="width: 200px; text-align:center;" for="d">Cukup Sering</label>
                                                                    </div>
                                                                    <div style="display: inline-block; margin:5px;">
                                                                    <input style="width: 200px; text-align:center;" type="radio" name="opsi6" id="e" value="e"><br><label style="width: 200px; text-align:center;" for="e">Sering Sekali</label>
                                                                    </div>
                                                            </div>
                                                        <br>

                                                        </div>
                                                        <div class="col-12">
                                                        <div class="form-group">
                                                                <h6 for="soal1">7. Dalam sebulan terakhir, seberapa sering Anda menemukan bahwa Anda tidak dapat mengatasi segala hal yang harus dilakukan?</h6>
                                                                
                                                                    <div  style="display: inline-block; margin:5px;">
                                                                    <input style="width: 200px; text-align:center;" type="radio" name="opsi7" id="a" value="a" required><br><label style="width: 200px; text-align:center;" for="a">Tidak Pernah</label>
                                                                    </div>
                                                                    <div style="display: inline-block; margin:5px;">
                                                                    <input style="width: 200px; text-align:center;" type="radio" name="opsi7" id="b" value="b"><br><label style="width: 200px; text-align:center;" for="b">Jarang</label>
                                                                    </div>
                                                                    <div style="display: inline-block; margin:5px;">
                                                                    <input style="width: 200px; text-align:center;" type="radio" name="opsi7" id="c" value="c"><br><label style="width: 200px; text-align:center;" for="c">Kadang-kadang</label>
                                                                    </div>
                                                                    <div style="display: inline-block; margin:5px;">
                                                                    <input style="width: 200px; text-align:center;" type="radio" name="opsi7" id="d" value="d"><br><label style="width: 200px; text-align:center;" for="d">Cukup Sering</label>
                                                                    </div>
                                                                    <div style="display: inline-block; margin:5px;">
                                                                    <input style="width: 200px; text-align:center;" type="radio" name="opsi7" id="e" value="e"><br><label style="width: 200px; text-align:center;" for="e">Sering Sekali</label>
                                                                    </div>
                                                            </div>
                                                        <br>

                                                        </div>
                                                        <div class="col-12">
                                                        <div class="form-group">
                                                                <h6 for="soal1">8. Dalam sebulan terakhir, seberapa sering Anda merasa bahwa Anda dapat mengendalikan hal-hal dalam hidup Anda?</h6>
                                                                
                                                                    <div  style="display: inline-block; margin:5px;">
                                                                    <input style="width: 200px; text-align:center;" type="radio" name="opsi8" id="a" value="a" required><br><label style="width: 200px; text-align:center;" for="a">Tidak Pernah</label>
                                                                    </div>
                                                                    <div style="display: inline-block; margin:5px;">
                                                                    <input style="width: 200px; text-align:center;" type="radio" name="opsi8" id="b" value="b"><br><label style="width: 200px; text-align:center;" for="b">Jarang</label>
                                                                    </div>
                                                                    <div style="display: inline-block; margin:5px;">
                                                                    <input style="width: 200px; text-align:center;" type="radio" name="opsi8" id="c" value="c"><br><label style="width: 200px; text-align:center;" for="c">Kadang-kadang</label>
                                                                    </div>
                                                                    <div style="display: inline-block; margin:5px;">
                                                                    <input style="width: 200px; text-align:center;" type="radio" name="opsi8" id="d" value="d"><br><label style="width: 200px; text-align:center;" for="d">Cukup Sering</label>
                                                                    </div>
                                                                    <div style="display: inline-block; margin:5px;">
                                                                    <input style="width: 200px; text-align:center;" type="radio" name="opsi8" id="e" value="e"><br><label style="width: 200px; text-align:center;" for="e">Sering Sekali</label>
                                                                    </div>
                                                            </div>
                                                        <br>

                                                        </div>
                                                        <div class="col-12">
                                                        <div class="form-group">
                                                                <h6 for="soal1">9. Dalam sebulan terakhir, seberapa sering Anda merasa marah karena hal-hal yang terjadi di luar kendali Anda?</h6>
                                                                
                                                                    <div  style="display: inline-block; margin:5px;">
                                                                    <input style="width: 200px; text-align:center;" type="radio" name="opsi9" id="a" value="a" required><br><label style="width: 200px; text-align:center;" for="a">Tidak Pernah</label>
                                                                    </div>
                                                                    <div style="display: inline-block; margin:5px;">
                                                                    <input style="width: 200px; text-align:center;" type="radio" name="opsi9" id="b" value="b"><br><label style="width: 200px; text-align:center;" for="b">Jarang</label>
                                                                    </div>
                                                                    <div style="display: inline-block; margin:5px;">
                                                                    <input style="width: 200px; text-align:center;" type="radio" name="opsi9" id="c" value="c"><br><label style="width: 200px; text-align:center;" for="c">Kadang-kadang</label>
                                                                    </div>
                                                                    <div style="display: inline-block; margin:5px;">
                                                                    <input style="width: 200px; text-align:center;" type="radio" name="opsi9" id="d" value="d"><br><label style="width: 200px; text-align:center;" for="d">Cukup Sering</label>
                                                                    </div>
                                                                    <div style="display: inline-block; margin:5px;">
                                                                    <input style="width: 200px; text-align:center;" type="radio" name="opsi9" id="e" value="e"><br><label style="width: 200px; text-align:center;" for="e">Sering Sekali</label>
                                                                    </div>
                                                            </div>
                                                        <br>

                                                        </div>
                                                        <div class="col-12">
                                                        <div class="form-group">
                                                                <h6 for="soal1">10. Dalam sebulan terakhir, seberapa sering Anda merasa ada berbagai kesulitan yang menumpuk begitu banyak sehingga Anda tidak dapat mengatasinya?</h6>
                                                                
                                                                    <div  style="display: inline-block; margin:5px;">
                                                                    <input style="width: 200px; text-align:center;" type="radio" name="opsi0" id="a" value="a" required><br><label style="width: 200px; text-align:center;" for="a">Tidak Pernah</label>
                                                                    </div>
                                                                    <div style="display: inline-block; margin:5px;">
                                                                    <input style="width: 200px; text-align:center;" type="radio" name="opsi0" id="b" value="b"><br><label style="width: 200px; text-align:center;" for="b">Jarang</label>
                                                                    </div>
                                                                    <div style="display: inline-block; margin:5px;">
                                                                    <input style="width: 200px; text-align:center;" type="radio" name="opsi0" id="c" value="c"><br><label style="width: 200px; text-align:center;" for="c">Kadang-kadang</label>
                                                                    </div>
                                                                    <div style="display: inline-block; margin:5px;">
                                                                    <input style="width: 200px; text-align:center;" type="radio" name="opsi0" id="d" value="d"><br><label style="width: 200px; text-align:center;" for="d">Cukup Sering</label>
                                                                    </div>
                                                                    <div style="display: inline-block; margin:5px;">
                                                                    <input style="width: 200px; text-align:center;" type="radio" name="opsi0" id="e" value="e"><br><label style="width: 200px; text-align:center;" for="e">Sering Sekali</label>
                                                                    </div>
                                                            </div>
                                                        <br>

                                                        </div>
                                                        <div class="col-12 d-flex justify-content-end">
                                                            <button type="submit" value="submit"  class="btn btn-primary me-1 mb-1">Submit</button>
                                                            <!-- <button type="reset" class="btn btn-light-secondary me-1 mb-1">Reset</button> -->
                                                        </div>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>
                </div>
                
                            </div>