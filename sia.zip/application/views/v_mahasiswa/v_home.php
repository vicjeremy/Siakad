            <div class="content-wrapper container">
                
<div class="page-heading">
    <h5>Selamat Datang di SIAKAD UNKARTUR</h5>
</div>
<div class="page-content">
    <section class="row">
        <div class="col-12 col-lg-14">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h4>Hi, <strong><?= $nama ?></strong> dengan NIM <strong><?= $nim ?></strong></h4>
                        </div>
                        <div class="card-body">
                            <p>Saat ini kamu adalah seorang <strong><?= $akses ?></strong> jurusan <strong><?= $jrs ?></strong> fakultas <strong><?= $fakul ?></strong> angkatan <strong><?= $akt ?></strong> yang telah berhasil menempuh <strong><?= $sks ?> sks dari 256 sks</strong>. Tetap semangat belajar, ya!</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>

            </div>