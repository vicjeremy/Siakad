<div class="content-wrapper container">
                <div class="page-content">
                    <section class="row">
                        <div class="col-12 col-lg-14">
                            <div class="row">
                                <div class="col-12">
                                    <div class="card">
                                        <div class="card-header">
                                            <h4 style="text-align:center; position: relative">Hi, <strong><?= $nama ?></strong></h4>
                                        </div>
                                        <div class="card-body">
                                            <h6 style="text-align:center; position: relative">Tingkat Stressmu <strong><?= $stress; ?></strong></h6>
                                            <br>
                                            <h6 style="text-align:center; position: relative">Kadar Stressmu <strong><?= $persen; ?></strong></h6>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>
                </div>
                
</div>