            <footer>
                <div class="container">
                    <div class="footer clearfix mb-0 text-muted">
                        <div class="float-start">
                            <p>2023 &copy;</p>
                        </div>
                        <div class="float-end">
                            <p>Crafted with <span class="text-danger"><i class="bi bi-heart"></i></span> by <a href="#">Vic Jeremy</a></p>
                        </div>
                    </div>
                </div>
            </footer>
            </div>
            </div>
            <script src="<?= base_url() ?>assets/static/js/components/dark.js"></script>
            <script src="<?= base_url() ?>assets/static/js/pages/horizontal-layout.js"></script>
            <script src="<?= base_url() ?>assets/extensions/perfect-scrollbar/perfect-scrollbar.min.js"></script>

            <script src="<?= base_url() ?>assets/compiled/js/app.js"></script>

            <script src="<?= base_url() ?>assets/extensions/jquery/jquery.min.js"></script>
            <script src="<?= base_url() ?>assets/extensions/datatables.net/js/jquery.dataTables.min.js"></script>
            <script src="<?= base_url() ?>assets/extensions/datatables.net-bs5/js/dataTables.bootstrap5.min.js"></script>
            <script src="<?= base_url() ?>assets/static/js/pages/datatables.js"></script>

            <!-- <script src="<?= base_url() ?>assets/extensions/apexcharts/apexcharts.min.js"></script> -->
            <!-- <script src="<?= base_url() ?>assets/static/js/pages/dashboard.js"></script> -->
            <script src="<?= base_url() ?>assets/extensions/sweetalert2/sweetalert2.min.js"></script>
            <script src="<?= base_url() ?>assets/extensions/sweetalert2/sweetalert2.js"></script>

            <!-- <script src="<?= base_url() ?>assets/custom.js"></script>> -->

            </body>

            </html>