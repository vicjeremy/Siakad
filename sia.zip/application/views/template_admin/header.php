<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="<?= base_url() ?>assets/unkartur/logoPT.png">
    <title>SIAKAD UNKARTUR</title>

  <link rel="stylesheet" href="<?= base_url() ?>/assets/compiled/css/app.css">
  <link rel="stylesheet" href="<?= base_url() ?>/assets/compiled/css/app-dark.css">
  <link rel="stylesheet" href="<?= base_url() ?>/assets/compiled/css/iconly.css">
  <link rel="stylesheet" href="<?= base_url() ?>/assets/extensions/sweetalert2/sweetalert2.min.css">
  <link rel="stylesheet" href="<?= base_url() ?>/assets/extensions/sweetalert2/sweetalert2.css">
  <!-- <link rel="stylesheet" href="<?= base_url() ?>/assets/custom.css"> -->
  <link rel="stylesheet" href="<?= base_url() ?>/assets/extensions/@icon/dripicons/dripicons.css">
  <link rel="stylesheet" href="<?= base_url() ?>/assets/compiled/css/ui-icons-dripicons.css">
  <link rel="stylesheet" href="<?= base_url() ?>/assets/extensions/@fortawesome/fontawesome-free/css/all.min.css">
  
  <link rel="stylesheet" href="<?= base_url() ?>/assets/extensions/datatables.net-bs5/css/dataTables.bootstrap5.min.css">
  <link rel="stylesheet" href="<?= base_url() ?>/assets/compiled/css/table-datatable-jquery.css">


</head>